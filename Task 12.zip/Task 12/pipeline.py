import re
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from hotel_qna_dataset import QNA_DATA


def preprocess(text: str) -> str:
    """
    Lowercase, strip punctuation, collapse whitespace.
    Same normalisation applied to both dataset questions
    and incoming user queries so embeddings align correctly.
    """
    text = text.lower().strip()
    text = re.sub(r"[^a-z0-9\s]", " ", text)  
    text = re.sub(r"\s+", " ", text)            
    return text



class HotelSearchEngine:
    """
    TF-IDF + Cosine Similarity search engine.

    Equivalent pipeline to HadithBot.ipynb:
      HadithBot              This Bot
      ──────────────────     ──────────────────────────────
      HuggingFace MiniLM  →  TfidfVectorizer (embed questions)
      FAISS IndexFlatL2   →  L2-normalised matrix (vector store)
      faiss.search()      →  cosine_similarity() (nearest neighbour)
    """

    def __init__(self, qna_pairs, top_k=1, threshold=0.15):
        self.questions = [preprocess(q) for q, _ in qna_pairs]
        self.answers   = [a for _, a in qna_pairs]
        self.raw_questions = [q for q, _ in qna_pairs]
        self.top_k     = top_k
        self.threshold = threshold

        
        self.vectorizer = TfidfVectorizer(
            ngram_range=(1, 2),   
            min_df=1,
            sublinear_tf=True    
        )
        self.index_matrix = self.vectorizer.fit_transform(self.questions)
        

        print(f"[Pipeline] Preprocessed {len(self.questions)} QnA pairs.")
        print(f"[Pipeline] Embedding vocab size: {len(self.vectorizer.vocabulary_)}")
        print(f"[Pipeline] Index matrix shape  : {self.index_matrix.shape}")


    def search(self, user_query: str) -> dict:
        """
        Embed the user query, then find the most similar
        question in the index using cosine similarity.

        Returns a dict with: answer, matched_question, score, found
        """
        clean_query = preprocess(user_query)
        query_vec   = self.vectorizer.transform([clean_query])

        
        scores = cosine_similarity(query_vec, self.index_matrix).flatten()

        best_idx   = int(np.argmax(scores))
        best_score = float(scores[best_idx])

        if best_score < self.threshold:
            return {
                "found": False,
                "answer": (
                    "🤔 I'm not sure about that. Try asking about:<br><br>"
                    "🛏️ <b>rooms</b> — room types and features<br>"
                    "💰 <b>prices</b> — room rates<br>"
                    "✨ <b>amenities</b> — hotel facilities<br>"
                    "📅 <b>booking</b> — how to reserve<br>"
                    "📍 <b>location</b> — where we are<br>"
                    "📞 <b>contact</b> — reach us"
                ),
                "matched_question": None,
                "score": round(best_score, 4)
            }

        return {
            "found": True,
            "answer": self.answers[best_idx],
            "matched_question": self.raw_questions[best_idx],
            "score": round(best_score, 4)
        }



print("\n========================================")
print("  Building Hotel QnA Search Index...")
print("========================================")
engine = HotelSearchEngine(QNA_DATA, top_k=1, threshold=0.12)
print("========================================\n")


def get_answer(user_query: str) -> str:
    result = engine.search(user_query)
    return result["answer"]
