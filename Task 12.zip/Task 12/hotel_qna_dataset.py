QNA_DATA = [
    # ---------- Greetings ----------
    ("hello", "👋 Welcome to The Grand Horizon Hotel! I'm your virtual concierge. Ask me about rooms, prices, amenities, booking, or location!"),
    ("hi there", "Hi! Welcome to The Grand Horizon Hotel. How can I assist you today?"),
    ("good morning", "Good morning! Welcome to The Grand Horizon Hotel. How may I help you?"),

    # ---------- Room Types ----------
    ("what room types do you have", "We offer four room types: Standard Room (PKR 8,000/night), Deluxe Room (PKR 13,500/night), Executive Suite (PKR 25,000/night), and Family Room (PKR 18,000/night)."),
    ("tell me about all rooms", "🛏️ Standard Room – PKR 8,000/night | 🌟 Deluxe Room – PKR 13,500/night | 👑 Executive Suite – PKR 25,000/night | 👨‍👩‍👧‍👦 Family Room – PKR 18,000/night. Ask me about any specific room for full details!"),
    ("show me your rooms", "We have 4 beautiful room categories: Standard, Deluxe, Executive Suite, and Family Room. Which one would you like to know more about?"),

    # ---------- Standard Room ----------
    ("tell me about standard room", "🛏️ Standard Room — PKR 8,000/night. Size: 28 sq m | 1 Queen Bed | Up to 2 guests. Amenities: Free WiFi, AC, 32\" LED TV, Mini Fridge, Room Service, Daily Housekeeping."),
    ("what is the price of standard room", "The Standard Room is priced at PKR 8,000 per night. It includes Free WiFi, AC, Mini Fridge, and Room Service."),
    ("standard room amenities", "Standard Room amenities include: Free WiFi, Air Conditioning, 32\" LED TV, Mini Fridge, Room Service, and Daily Housekeeping."),
    ("how many guests can stay in standard room", "The Standard Room can accommodate up to 2 guests. It has 1 Queen Bed."),

    # ---------- Deluxe Room ----------
    ("tell me about deluxe room", "🌟 Deluxe Room — PKR 13,500/night. Size: 38 sq m | 1 King Bed or 2 Twin Beds | Up to 3 guests. Amenities: Free WiFi, AC, 43\" Smart TV, Mini Bar, Bathtub, Room Service, City View, Complimentary Breakfast."),
    ("what is the price of deluxe room", "The Deluxe Room costs PKR 13,500 per night. It includes complimentary breakfast, city view, and a 43\" Smart TV."),
    ("deluxe room features", "The Deluxe Room (38 sq m) features: King or Twin Beds, Smart TV, Mini Bar, Bathtub, City View, and complimentary breakfast for all guests."),
    ("does deluxe room include breakfast", "Yes! The Deluxe Room includes complimentary breakfast served at The Horizon Restaurant from 7:00 AM to 10:30 AM."),

    # ---------- Executive Suite ----------
    ("tell me about executive suite", "👑 Executive Suite — PKR 25,000/night. Size: 65 sq m | King Bed + Sofa Bed | Up to 4 guests. Amenities: WiFi, 55\" Smart TV, Full Mini Bar, Jacuzzi, Separate Living Room, Panoramic View, Breakfast & Dinner, Airport Transfer."),
    ("executive suite price", "The Executive Suite is PKR 25,000 per night. It includes breakfast AND dinner, airport transfer, Jacuzzi, and panoramic city views."),
    ("what does executive suite include", "The Executive Suite includes: 55\" Smart TV, Full Mini Bar, Jacuzzi, Separate Living Room, Panoramic View, Complimentary Breakfast & Dinner, and free Airport Transfer."),
    ("does executive suite have jacuzzi", "Yes! The Executive Suite features a luxurious Jacuzzi, along with a separate living room, panoramic views, and complimentary meals."),

    # ---------- Family Room ----------
    ("tell me about family room", "👨‍👩‍👧‍👦 Family Room — PKR 18,000/night. Size: 52 sq m | 1 King Bed + 2 Single Beds | Up to 5 guests. Amenities: WiFi, AC, 43\" Smart TV, Mini Fridge, Kids Welcome Kit, Room Service, Bathtub, Complimentary Breakfast."),
    ("family room price", "The Family Room is priced at PKR 18,000 per night and can host up to 5 guests. It includes a Kids Welcome Kit and complimentary breakfast."),
    ("is family room good for children", "Absolutely! The Family Room is perfect for families. It comes with a Kids Welcome Kit, 2 Single Beds, King Bed, Bathtub, and complimentary breakfast."),
    ("how many people can stay in family room", "The Family Room can accommodate 4–5 guests. It has 1 King Bed and 2 Single Beds, making it ideal for families."),

    # ---------- Prices ----------
    ("what are your room prices", "Room rates per night: Standard – PKR 8,000 | Deluxe – PKR 13,500 | Family – PKR 18,000 | Executive Suite – PKR 25,000. Prices include taxes."),
    ("how much does it cost to stay", "Our nightly rates: Standard (PKR 8,000), Deluxe (PKR 13,500), Family (PKR 18,000), Executive Suite (PKR 25,000). All prices include taxes."),
    ("room charges", "Room charges per night: Standard PKR 8,000 | Deluxe PKR 13,500 | Family Room PKR 18,000 | Executive Suite PKR 25,000."),
    ("cheapest room", "Our most affordable option is the Standard Room at PKR 8,000/night, featuring Free WiFi, AC, Mini Fridge, and Room Service."),
    ("most expensive room", "Our most luxurious option is the Executive Suite at PKR 25,000/night, featuring a Jacuzzi, panoramic views, and complimentary meals."),

    # ---------- Amenities ----------
    ("what amenities do you have", "✨ Hotel facilities include: Heated Rooftop Pool, 24/7 Fitness Center, Spa & Wellness, The Horizon Restaurant, Free Valet Parking, High-Speed WiFi, Laundry Service, Conference Halls, and Airport Transfer."),
    ("what facilities are available", "Our facilities: 🏊 Rooftop Pool | 💪 Gym (24/7) | 💆 Spa | 🍽️ Restaurant | 🚗 Free Parking | 📶 WiFi | 👔 Laundry | 📊 Conference Halls | ✈️ Airport Transfer."),
    ("hotel services", "Services available: Room Service, Valet Parking, Laundry & Dry Cleaning, Airport Transfer, Spa Treatments, Fitness Center, Business Conference Halls, and 24/7 Front Desk."),

    # ---------- Pool ----------
    ("do you have a swimming pool", "Yes! 🏊 We have a Heated Rooftop Swimming Pool on the 7th Floor, open daily from 7 AM to 10 PM for all guests."),
    ("pool timings", "The Rooftop Swimming Pool is open from 7:00 AM to 10:00 PM daily. It's located on the 7th Floor."),
    ("is there a pool", "Absolutely! Our Heated Rooftop Pool is on the 7th Floor and open from 7 AM to 10 PM every day."),

    # ---------- Gym ----------
    ("do you have a gym", "💪 Yes! Our Fitness Center is open 24/7 and equipped with modern equipment. A personal trainer is also available on request."),
    ("gym timings", "The Fitness Center is open 24 hours a day, 7 days a week. Personal trainer services are available."),
    ("fitness center", "Our fully equipped Fitness Center is available 24/7 with modern workout equipment and an optional personal trainer."),

    # ---------- Spa ----------
    ("do you have a spa", "💆 Yes! Our Spa & Wellness Center is open from 9 AM to 9 PM daily. Services include massage, facial, and steam room (charges apply)."),
    ("spa services", "Spa & Wellness services include: massage therapy, facial treatments, and steam room. Open 9 AM – 9 PM. Additional charges apply."),
    ("spa timings", "The Spa & Wellness Center is open from 9:00 AM to 9:00 PM every day. Services: massage, facial, steam room."),

    # ---------- Restaurant ----------
    ("do you have a restaurant", "🍽️ Yes! The Horizon Restaurant is open from 7 AM to 11 PM, serving Pakistani, Chinese, and Continental cuisine."),
    ("restaurant menu", "The Horizon Restaurant serves Pakistani, Chinese, and Continental cuisine. Open 7:00 AM – 11:00 PM daily."),
    ("restaurant timings", "The Horizon Restaurant is open daily from 7:00 AM to 11:00 PM. It offers a wide range of Pakistani, Chinese, and Continental dishes."),
    ("what food do you serve", "Our restaurant serves a diverse menu of Pakistani, Chinese, and Continental cuisine. Open 7 AM to 11 PM daily."),

    # ---------- Breakfast ----------
    ("is breakfast included", "Breakfast is complimentary for Deluxe, Executive Suite, and Family Room guests. Standard Room guests can add breakfast for PKR 1,200/person."),
    ("breakfast timings", "Complimentary breakfast is served at The Horizon Restaurant from 7:00 AM to 10:30 AM."),
    ("breakfast price", "Breakfast for Standard Room guests costs PKR 1,200 per person. It's included free in Deluxe, Suite, and Family rooms."),

    # ---------- WiFi ----------
    ("is wifi free", "📶 Yes! Complimentary high-speed WiFi is available throughout the hotel. The WiFi password is provided at check-in."),
    ("wifi password", "The WiFi password is provided at the front desk upon check-in. High-speed internet is available everywhere in the hotel."),
    ("internet access", "Free high-speed WiFi is available across all hotel areas — rooms, lobby, restaurant, and pool. Password given at check-in."),

    # ---------- Parking ----------
    ("is parking available", "🚗 Yes! Free valet parking is available for all hotel guests. We have a secure underground parking facility."),
    ("parking charges", "Parking is completely FREE for all guests. We offer free valet parking with a secure underground parking lot."),
    ("valet parking", "Our free valet parking service is available 24/7. Simply hand your keys to our valet at the main entrance."),

    # ---------- Laundry ----------
    ("do you have laundry service", "👔 Yes! Laundry and dry cleaning services are available. Same-day service is provided for items dropped before 10:00 AM."),
    ("laundry charges", "Laundry and dry cleaning services are available at standard charges. Same-day service for items submitted before 10 AM."),

    # ---------- Conference / Events ----------
    ("do you have conference hall", "📊 Yes! We have 3 Conference Halls with capacity for 50 to 300 people. Contact us for corporate rates and event packages."),
    ("event venue", "We have 3 Conference Halls available for corporate events, seminars, and conferences. Capacity: 50–300 people. Contact us for packages."),
    ("meeting rooms", "Our Conference Halls can host meetings, seminars, and events for 50–300 attendees. Contact reservations for pricing."),

    # ---------- Airport Transfer ----------
    ("do you offer airport transfer", "✈️ Yes! Airport transfer is available 24/7 to/from Allama Iqbal International Airport. Cost: PKR 2,500 one way."),
    ("airport pickup price", "Airport transfer costs PKR 2,500 one way. Available 24/7 to and from Allama Iqbal International Airport. Book in advance."),
    ("how to get from airport to hotel", "We offer airport transfer for PKR 2,500 one way (24/7). Alternatively, the airport is about 25 minutes by taxi."),

    # ---------- Booking ----------
    ("how can i book a room", "You can book via: 📞 Phone: +92-42-3571-8800 | 📧 Email: reservations@grandhorizon.com | 🌐 Website: www.grandhorizon.com | 🏨 Walk-in at our 24/7 Front Desk."),
    ("how to make a reservation", "Reservations can be made by calling +92-42-3571-8800, emailing reservations@grandhorizon.com, or visiting our website."),
    ("reservation process", "To reserve a room: call +92-42-3571-8800, email reservations@grandhorizon.com, or book online at www.grandhorizon.com. Payment: Visa, Mastercard, Cash, or Bank Transfer."),
    ("online booking", "You can book online at www.grandhorizon.com. We also accept bookings via phone (+92-42-3571-8800) and email."),
    ("payment methods", "We accept Visa, Mastercard, Cash, and Bank Transfer for all reservations and hotel services."),

    # ---------- Check-in / Check-out ----------
    ("what is check in time", "Check-in time is 2:00 PM. Early check-in from 10 AM is available for an additional PKR 2,000 (subject to availability)."),
    ("what is check out time", "Check-out time is 12:00 PM (Noon). Late check-out until 3 PM is available for PKR 2,000 extra."),
    ("early check in", "Early check-in is available from 10:00 AM for an additional charge of PKR 2,000. Please inform us in advance."),
    ("late check out", "Late check-out until 3:00 PM is available for PKR 2,000 extra. Subject to availability — please request in advance."),

    # ---------- Cancellation ----------
    ("what is your cancellation policy", "Cancellation policy: 48+ hours before → Full refund ✅ | 24–48 hours → 50% refund | Less than 24 hours → No refund ❌ | No-show → Full charge."),
    ("can i cancel my booking", "Yes, you can cancel. Full refund if cancelled 48+ hours before check-in. 50% refund for 24–48 hours. No refund within 24 hours."),
    ("refund policy", "Refunds: Full refund (48+ hrs before), 50% refund (24–48 hrs), No refund (<24 hrs). To cancel, call or email reservations@grandhorizon.com."),

    # ---------- Location ----------
    ("where is the hotel located", "📍 The Grand Horizon Hotel is located in Gulberg III, Lahore, Pakistan — near Hussain Chowk, MM Alam Road, and Liberty Market."),
    ("hotel address", "Our address: The Grand Horizon Hotel, Gulberg III, Lahore, Pakistan. 25 minutes from Allama Iqbal International Airport."),
    ("how to reach the hotel", "We're in Gulberg III, Lahore — 25 mins from the airport. Airport transfer available (PKR 2,500). Near MM Alam Road and Liberty Market."),
    ("nearby places", "We're close to Liberty Market, MM Alam Road, Hussain Chowk, and Gulberg Main Boulevard — right in the heart of Lahore."),

    # ---------- Contact ----------
    ("what is your phone number", "📞 Our phone number is +92-42-3571-8800. Our front desk is available 24/7."),
    ("hotel email address", "📧 Our email is reservations@grandhorizon.com. We typically respond within a few hours."),
    ("how to contact the hotel", "Contact us: 📞 +92-42-3571-8800 | 📧 reservations@grandhorizon.com | 🌐 www.grandhorizon.com | Front Desk: 24/7."),

    # ---------- Pets ----------
    ("are pets allowed", "🐾 We're sorry, pets are not allowed inside the hotel premises. Thank you for your understanding."),
    ("can i bring my dog", "Unfortunately, pets and animals are not permitted inside the hotel. We apologize for any inconvenience."),

    # ---------- Smoking ----------
    ("is smoking allowed", "🚭 The Grand Horizon Hotel is a non-smoking property. Designated smoking areas are available outside the building."),
    ("smoking rooms", "We do not offer smoking rooms. The hotel is entirely non-smoking. Outdoor smoking areas are available."),

    # ---------- General ----------
    ("what is the hotel rating", "⭐ The Grand Horizon Hotel is a 5-Star rated property in Lahore, Pakistan."),
    ("is this a 5 star hotel", "Yes! The Grand Horizon Hotel is a proud 5-Star rated hotel located in Gulberg III, Lahore."),
    ("thank you", "😊 You're most welcome! It's our pleasure to assist you. Is there anything else I can help with?"),
    ("bye", "👋 Thank you for choosing The Grand Horizon Hotel! We look forward to welcoming you. Have a wonderful day! 🌟"),
]
