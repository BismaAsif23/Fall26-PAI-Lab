from flask import Flask, render_template, request, jsonify
from pipeline import get_answer, engine

app = Flask(__name__)


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/chat", methods=["POST"])
def chat():
    data     = request.get_json()
    user_msg = data.get("message", "").strip()

    if not user_msg:
        return jsonify({"reply": "Please type a message!", "score": 0})

    result = engine.search(user_msg)

    return jsonify({
        "reply":   result["answer"],
        "score":   result["score"],
        "matched": result.get("matched_question", "")
    })


@app.route("/pipeline-info")
def pipeline_info():
    """Shows index stats — useful for demonstrating the pipeline."""
    return jsonify({
        "total_qna_pairs": len(engine.questions),
        "vocab_size":       len(engine.vectorizer.vocabulary_),
        "index_shape":      list(engine.index_matrix.shape),
        "threshold":        engine.threshold,
        "pipeline": [
            "1. Preprocess: lowercase + strip punctuation + collapse whitespace",
            "2. Embed: TF-IDF vectorisation (ngram 1-2, sublinear_tf)",
            "3. Index: sparse matrix stored in memory (FAISS equivalent)",
            "4. Search: cosine_similarity() nearest-neighbour lookup"
        ]
    })


if __name__ == "__main__":
    app.run(debug=True, port=5000)
