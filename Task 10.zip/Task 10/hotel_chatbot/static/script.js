const chatMessages = document.getElementById("chatMessages");
const userInput    = document.getElementById("userInput");

// ── Add a message bubble ──────────────────────────────────────
function addMessage(text, sender) {
  const wrapper = document.createElement("div");
  wrapper.className = `message ${sender}`;

  const icon = document.createElement("div");
  icon.className = "msg-icon";
  icon.textContent = sender === "bot" ? "🏨" : "👤";

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.innerHTML = text;

  wrapper.appendChild(icon);
  wrapper.appendChild(bubble);
  chatMessages.appendChild(wrapper);
  scrollToBottom();
}

// ── Typing indicator ──────────────────────────────────────────
function showTyping() {
  const wrapper = document.createElement("div");
  wrapper.className = "typing-indicator";
  wrapper.id = "typingIndicator";
  wrapper.innerHTML = `
    <div class="msg-icon" style="background:#1a1209;border:1px solid rgba(201,169,110,0.4)">🏨</div>
    <div class="typing-dots">
      <span></span><span></span><span></span>
    </div>
  `;
  chatMessages.appendChild(wrapper);
  scrollToBottom();
}

function hideTyping() {
  const el = document.getElementById("typingIndicator");
  if (el) el.remove();
}

function scrollToBottom() {
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

// ── Send message ──────────────────────────────────────────────
async function sendMessage() {
  const text = userInput.value.trim();
  if (!text) return;

  addMessage(text, "user");
  userInput.value = "";
  userInput.focus();

  showTyping();

  try {
    const res  = await fetch("/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text })
    });
    const data = await res.json();

    // Small delay so typing feels natural
    setTimeout(() => {
      hideTyping();
      addMessage(data.reply, "bot");
    }, 700);

  } catch (err) {
    hideTyping();
    addMessage("⚠️ Connection error. Please try again.", "bot");
  }
}

// ── Quick ask buttons ─────────────────────────────────────────
function quickAsk(text) {
  userInput.value = text;
  sendMessage();
}

// ── Welcome message on load ───────────────────────────────────
window.addEventListener("DOMContentLoaded", () => {
  setTimeout(() => {
    addMessage(
      "👋 Welcome to <b>The Grand Horizon Hotel</b>! I'm your virtual concierge.<br><br>" +
      "I can help you with:<br>" +
      "🛏️ <b>Room Types & Prices</b><br>" +
      "✨ <b>Hotel Amenities</b><br>" +
      "📅 <b>Booking Information</b><br>" +
      "📍 <b>Location & Contact</b><br><br>" +
      "Use the quick buttons on the left or type your question below! 😊",
      "bot"
    );
  }, 400);
});
