from flask import Flask, render_template, request, jsonify
import re

app = Flask(__name__)


HOTEL_INFO = {
    "name": "The Grand Horizon Hotel",
    "location": "Gulberg III, Lahore, Pakistan",
    "phone": "+92-42-3571-8800",
    "email": "reservations@grandhorizon.com",
    "checkin": "2:00 PM",
    "checkout": "12:00 PM (Noon)",
    "rating": "5-Star",
}

ROOMS = {
    "standard": {
        "name": "Standard Room",
        "price": "PKR 8,000 / night",
        "size": "28 sq m",
        "beds": "1 Queen Bed",
        "capacity": "2 guests",
        "amenities": ["Free WiFi", "AC", "32\" LED TV", "Mini Fridge", "Room Service", "Daily Housekeeping"],
        "emoji": "🛏️"
    },
    "deluxe": {
        "name": "Deluxe Room",
        "price": "PKR 13,500 / night",
        "size": "38 sq m",
        "beds": "1 King Bed or 2 Twin Beds",
        "capacity": "2–3 guests",
        "amenities": ["Free WiFi", "AC", "43\" Smart TV", "Mini Bar", "Bathtub", "Room Service", "City View", "Complimentary Breakfast"],
        "emoji": "🌟"
    },
    "suite": {
        "name": "Executive Suite",
        "price": "PKR 25,000 / night",
        "size": "65 sq m",
        "beds": "1 King Bed + Sofa Bed",
        "capacity": "3–4 guests",
        "amenities": ["Free WiFi", "AC", "55\" Smart TV", "Full Mini Bar", "Jacuzzi", "Separate Living Room", "Panoramic View", "Complimentary Breakfast & Dinner", "Airport Transfer"],
        "emoji": "👑"
    },
    "family": {
        "name": "Family Room",
        "price": "PKR 18,000 / night",
        "size": "52 sq m",
        "beds": "1 King Bed + 2 Single Beds",
        "capacity": "4–5 guests",
        "amenities": ["Free WiFi", "AC", "43\" Smart TV", "Mini Fridge", "Kids Welcome Kit", "Room Service", "Bathtub", "Complimentary Breakfast"],
        "emoji": "👨‍👩‍👧‍👦"
    }
}

AMENITIES = {
    "pool": "🏊 Heated Swimming Pool — Open 7 AM to 10 PM daily (Rooftop, 7th Floor)",
    "gym": "💪 Fitness Center — Open 24/7 with modern equipment, personal trainer available",
    "spa": "💆 Spa & Wellness Center — Open 9 AM to 9 PM. Services: massage, facial, steam room (charges apply)",
    "restaurant": "🍽️ The Horizon Restaurant — Open 7 AM to 11 PM. Serves Pakistani, Chinese & Continental cuisine",
    "parking": "🚗 Free valet parking available for all guests. Secure underground parking",
    "wifi": "📶 Complimentary high-speed WiFi throughout the hotel. Password given at check-in",
    "laundry": "👔 Laundry & dry cleaning service available. Same-day service before 10 AM",
    "conference": "📊 3 Conference Halls available for events (capacity: 50–300 people). Contact us for corporate rates",
    "airport": "✈️ Airport transfer available 24/7. To/from Allama Iqbal Airport — PKR 2,500 one way",
}


def get_bot_reply(message):
    msg = message.lower().strip()


    if any(w in msg for w in ["hello", "hi", "hey", "salam", "assalam", "good morning", "good evening", "good afternoon"]):
        return (
            f"👋 Welcome to <b>{HOTEL_INFO['name']}</b>! I'm your virtual concierge.<br><br>"
            "I can help you with:<br>"
            "🛏️ <b>Room Types & Prices</b><br>"
            "✨ <b>Hotel Amenities</b><br>"
            "📅 <b>Booking Information</b><br>"
            "📍 <b>Location & Contact</b><br><br>"
            "What would you like to know?"
        )

    if any(w in msg for w in ["rooms", "room types", "all rooms", "available rooms", "what rooms"]):
        reply = "🏨 <b>Our Room Types:</b><br><br>"
        for key, room in ROOMS.items():
            reply += f"{room['emoji']} <b>{room['name']}</b> — {room['price']}<br>"
        reply += "<br>Ask about any room for full details! (e.g. <i>'tell me about deluxe room'</i>)"
        return reply

    for key, room in ROOMS.items():
        if key in msg or room["name"].lower() in msg:
            amenities_list = " • ".join(room["amenities"])
            return (
                f"{room['emoji']} <b>{room['name']}</b><br><br>"
                f"💰 <b>Price:</b> {room['price']}<br>"
                f"📐 <b>Size:</b> {room['size']}<br>"
                f"🛏️ <b>Beds:</b> {room['beds']}<br>"
                f"👥 <b>Capacity:</b> {room['capacity']}<br><br>"
                f"✅ <b>Amenities:</b><br>{amenities_list}"
            )

    if any(w in msg for w in ["price", "cost", "rate", "rates", "how much", "charges", "fee", "tariff"]):
        reply = "💰 <b>Room Rates per Night:</b><br><br>"
        for room in ROOMS.values():
            reply += f"{room['emoji']} {room['name']}: <b>{room['price']}</b><br>"
        reply += "<br>Prices include taxes. Breakfast included in Deluxe, Suite & Family rooms."
        return reply

    if any(w in msg for w in ["book", "booking", "reserve", "reservation", "how to book", "want to book"]):
        return (
            "📅 <b>How to Book a Room:</b><br><br>"
            "You can make a reservation through:<br><br>"
            f"📞 <b>Phone:</b> {HOTEL_INFO['phone']}<br>"
            f"📧 <b>Email:</b> {HOTEL_INFO['email']}<br>"
            "🌐 <b>Website:</b> www.grandhorizon.com<br>"
            "🏨 <b>Walk-in:</b> Front Desk (24/7)<br><br>"
            f"🕐 <b>Check-in:</b> {HOTEL_INFO['checkin']}<br>"
            f"🕛 <b>Check-out:</b> {HOTEL_INFO['checkout']}<br><br>"
            "💳 We accept Visa, Mastercard, Cash & Bank Transfer.<br>"
            "<i>Early check-in & late check-out available on request (charges may apply).</i>"
        )


    if any(w in msg for w in ["check in", "check-in", "checkin", "check out", "check-out", "checkout", "timing", "time"]):
        return (
            f"🕐 <b>Check-in Time:</b> {HOTEL_INFO['checkin']}<br>"
            f"🕛 <b>Check-out Time:</b> {HOTEL_INFO['checkout']}<br><br>"
            "Early check-in available from 10 AM (PKR 2,000 extra).<br>"
            "Late check-out until 3 PM (PKR 2,000 extra).<br>"
            "Subject to availability — please inform us in advance!"
        )


    if any(w in msg for w in ["amenities", "facilities", "services", "features", "what do you offer", "what you have"]):
        reply = "✨ <b>Hotel Facilities & Services:</b><br><br>"
        for item in AMENITIES.values():
            reply += f"{item}<br>"
        return reply


    for key, info in AMENITIES.items():
        if key in msg:
            return f"<b>About our {key.title()}:</b><br><br>{info}"


    if "breakfast" in msg:
        return (
            "🍳 <b>Breakfast Information:</b><br><br>"
            "• <b>Standard Room:</b> Not included (available for PKR 1,200/person)<br>"
            "• <b>Deluxe Room:</b> Complimentary breakfast included ✅<br>"
            "• <b>Executive Suite:</b> Breakfast & Dinner included ✅<br>"
            "• <b>Family Room:</b> Complimentary breakfast included ✅<br><br>"
            "🍽️ Served at The Horizon Restaurant — 7:00 AM to 10:30 AM"
        )

    if any(w in msg for w in ["location", "address", "where", "directions", "how to reach", "where are you"]):
        return (
            f"📍 <b>Our Location:</b><br><br>"
            f"<b>{HOTEL_INFO['name']}</b><br>"
            f"{HOTEL_INFO['location']}<br><br>"
            "🚗 <b>From Airport:</b> 25 minutes (Allama Iqbal International)<br>"
            "🏙️ <b>Near:</b> Hussain Chowk, MM Alam Road, Liberty Market<br><br>"
            f"✈️ <b>Airport Transfer:</b> PKR 2,500 one way (book in advance)<br>"
            f"📞 <b>Contact:</b> {HOTEL_INFO['phone']}"
        )

  
    if any(w in msg for w in ["contact", "phone", "email", "number", "call", "reach"]):
        return (
            f"📞 <b>Contact Us:</b><br><br>"
            f"📱 <b>Phone:</b> {HOTEL_INFO['phone']}<br>"
            f"📧 <b>Email:</b> {HOTEL_INFO['email']}<br>"
            "🌐 <b>Website:</b> www.grandhorizon.com<br>"
            "🕐 <b>Front Desk:</b> Available 24/7<br><br>"
            "We're happy to assist you anytime!"
        )

    
    if any(w in msg for w in ["cancel", "cancellation", "refund", "policy"]):
        return (
            "❌ <b>Cancellation Policy:</b><br><br>"
            "• Cancel <b>48+ hours</b> before check-in → Full refund ✅<br>"
            "• Cancel <b>24–48 hours</b> before → 50% refund<br>"
            "• Cancel <b>less than 24 hours</b> → No refund ❌<br>"
            "• No-show → Full charge applies<br><br>"
            "To cancel: call us or email reservations@grandhorizon.com"
        )


    if "pet" in msg or "dog" in msg or "cat" in msg or "animal" in msg:
        return "🐾 We're sorry, pets are <b>not allowed</b> inside the hotel premises. Thank you for understanding!"


    if "wifi" in msg or "internet" in msg or "password" in msg:
        return "📶 <b>Free high-speed WiFi</b> is available throughout the hotel for all guests. The WiFi password is provided at check-in. 😊"


    if "park" in msg or "parking" in msg or "car" in msg:
        return "🚗 <b>Free valet parking</b> is available for all hotel guests. We have a secure underground parking facility. Just hand your keys to our valet at the entrance!"


    if any(w in msg for w in ["thank", "thanks", "thankyou", "thank you", "shukriya"]):
        return "😊 You're welcome! It's our pleasure to assist you. Is there anything else I can help you with?"


    if any(w in msg for w in ["bye", "goodbye", "khuda hafiz", "see you", "exit", "quit"]):
        return f"👋 Thank you for choosing <b>{HOTEL_INFO['name']}</b>! We look forward to welcoming you. Have a wonderful day! 🌟"

  
    return (
        "🤔 I'm not sure I understood that. I can help you with:<br><br>"
        "🛏️ Type <b>'rooms'</b> — to see all room types<br>"
        "💰 Type <b>'prices'</b> — to see room rates<br>"
        "✨ Type <b>'amenities'</b> — to see hotel facilities<br>"
        "📅 Type <b>'booking'</b> — to make a reservation<br>"
        "📍 Type <b>'location'</b> — to find us<br>"
        "📞 Type <b>'contact'</b> — to reach us<br>"
    )



@app.route("/")
def home():
    return render_template("index.html")


@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    user_msg = data.get("message", "").strip()
    if not user_msg:
        return jsonify({"reply": "Please type a message!"})
    reply = get_bot_reply(user_msg)
    return jsonify({"reply": reply})


if __name__ == "__main__":
    app.run(debug=True)
