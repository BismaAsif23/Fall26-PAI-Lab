async function analyzeSentiment() {
  const text = document.getElementById("textInput").value.trim();

  if (!text) {
    alert("Please enter some text first!");
    return;
  }

  const response = await fetch("/analyze", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ text: text })
  });

  const data = await response.json();

  if (data.error) {
    alert(data.error);
    return;
  }

  // Show result box
  const resultBox = document.getElementById("resultBox");
  resultBox.classList.remove("hidden");

  // Set emoji and label
  document.getElementById("emoji").textContent = data.emoji;

  const label = document.getElementById("resultLabel");
  label.textContent = data.result;
  label.className = "result-label " + data.result.toLowerCase();

  // Set counts
  document.getElementById("posCount").textContent = data.positive_count;
  document.getElementById("negCount").textContent = data.negative_count;

  // Show found words
  const wordsDiv = document.getElementById("wordsFound");
  if (data.found_words.length > 0) {
    let tagsHTML = '<p>Keywords found:</p><div class="word-tags">';
    data.found_words.forEach(w => {
      tagsHTML += `<span class="tag ${w.type}">${w.word}</span>`;
    });
    tagsHTML += '</div>';
    wordsDiv.innerHTML = tagsHTML;
  } else {
    wordsDiv.innerHTML = '<p>No sentiment keywords found in this text.</p>';
  }
}

function setExample(text) {
  document.getElementById("textInput").value = text;
  analyzeSentiment();
}
