from flask import Flask, render_template, request, jsonify
import re

app = Flask(__name__)

positive_words = [
    "good", "great", "excellent", "amazing", "awesome", "love", "wonderful",
    "fantastic", "happy", "best", "nice", "perfect", "beautiful", "brilliant",
    "superb", "enjoy", "like", "pleased", "helpful", "impressive", "outstanding"
]

negative_words = [
    "bad", "terrible", "awful", "horrible", "hate", "worst", "poor", "ugly",
    "broken", "useless", "boring", "annoying", "disappointing", "sad", "angry",
    "fail", "slow", "wrong", "difficult", "confusing", "waste", "pathetic"
]

negations = ["not", "never", "no", "don't", "doesn't", "didn't", "isn't", "wasn't"]


def analyze_sentiment(text):
    # Clean and split text
    words = re.sub(r"[^\w\s']", "", text.lower()).split()

    pos_count = 0
    neg_count = 0
    found_words = []

    for i, word in enumerate(words):
        # Check negation (word before current)
        negated = i > 0 and words[i - 1] in negations

        if word in positive_words:
            if negated:
                neg_count += 1
                found_words.append({"word": "not " + word, "type": "negative"})
            else:
                pos_count += 1
                found_words.append({"word": word, "type": "positive"})

        elif word in negative_words:
            if negated:
                pos_count += 1
                found_words.append({"word": "not " + word, "type": "positive"})
            else:
                neg_count += 1
                found_words.append({"word": word, "type": "negative"})

    # Decide result
    if pos_count > neg_count:
        result = "Positive"
        emoji = "😊"
    elif neg_count > pos_count:
        result = "Negative"
        emoji = "😞"
    else:
        result = "Neutral"
        emoji = "😐"

    return {
        "result": result,
        "emoji": emoji,
        "positive_count": pos_count,
        "negative_count": neg_count,
        "found_words": found_words
    }


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/analyze", methods=["POST"])
def analyze():
    data = request.get_json()
    text = data.get("text", "").strip()

    if not text:
        return jsonify({"error": "Please enter some text!"})

    result = analyze_sentiment(text)
    return jsonify(result)


if __name__ == "__main__":
    app.run(debug=True)
