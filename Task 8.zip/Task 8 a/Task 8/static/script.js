async function loadJoke(){
    const box = document.getElementById("joke-box");
    box.innerText = "Loading...";
    const res = await fetch("/get_joke");
    const data = await res.json();
    box.innerText = data.joke;
}
window.onload = loadJoke;