from flask import Flask, render_template, jsonify
import requests

app = Flask(__name__)

JOKE_API = "https://official-joke-api.appspot.com/random_joke"

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get_joke")
def get_joke():
    try:
        r = requests.get(JOKE_API, timeout=5)
        data = r.json()
        joke = f"{data.get('setup','')} {data.get('punchline','')}".strip()
        return jsonify({"joke": joke})
    except Exception:
        return jsonify({"joke": "Could not fetch joke right now. Try again!"})

if __name__ == "__main__":
    app.run(debug=True)