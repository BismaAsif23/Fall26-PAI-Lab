from flask import Flask, jsonify
import requests
app = Flask(__name__)
@app.route('/joke', methods=['GET'])
def get_joke():
    api_url = "https://official-joke-api.appspot.com/random_joke"
    
    response = requests.get(api_url)  
    data = response.json()  
    
    joke = {
        "setup": data["setup"],  
        "punchline": data["punchline"] 
    }
    return jsonify(joke) 
@app.route('/')
def home():
    return jsonify({"message": "Welcome to Random Joke API! Use /joke to get a joke."})
if __name__ == "__main__":
    app.run(debug=True)